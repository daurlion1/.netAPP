﻿
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System.IO;
using WordToPDF;


namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("convert/to/pdf")]
   
    public class FileConverterController : ControllerBase
    {
        private readonly ILogger<FileConverterController> _logger;
        
        public FileConverterController(ILogger<FileConverterController> logger)
        {
            _logger = logger;
        }

      
        [HttpPost]
        public async Task<IActionResult> Download()
        {
            try
            {
                var files = Request.Form.Files;
                var file = files[0];
                string tempFilesPath = Path.Combine(Directory.GetCurrentDirectory(), "Files");
                string tempFilename = Path.Combine(tempFilesPath, file.FileName);
                var fileStream = new FileStream(tempFilename, FileMode.Create);
                file.CopyTo(fileStream);
                fileStream.Close();
                Word2Pdf objWorPdf = new Word2Pdf();
                string strFileName = file.FileName;
                object FromLocation = tempFilename;
                string FileExtension = Path.GetExtension(strFileName);
                string ChangeExtension = strFileName.Replace(FileExtension, ".pdf");
                if (FileExtension == ".doc" || FileExtension == ".docx")
                {
                    object ToLocation = Path.Combine(tempFilesPath, ChangeExtension);
                    objWorPdf.InputLocation = FromLocation;
                    objWorPdf.OutputLocation = ToLocation;
                    objWorPdf.Word2PdfCOnversion();
                }
                else
                {
                    var Error = new
                    {
                        message = "file must have extension .docx",
                    };
                    Response.StatusCode = 400;
                    return new JsonResult(Error);

                }
                System.IO.File.Delete(tempFilename);
                string ToLocations = Path.Combine(tempFilesPath, ChangeExtension);
                string file_type = "application/pdf";
                return TemporaryFile(ToLocations, file_type, ChangeExtension);
            }
            catch
            {
                var Error = new
                {
                    message = "Something went wrong",
                };
                Response.StatusCode = 500;
                return new JsonResult(Error);
            }
            
        }


        protected FileContentResult TemporaryFile(string fileName, string contentType, string fileDownloadName)
        {
            var bytes = System.IO.File.ReadAllBytes(fileName);
            System.IO.File.Delete(fileName);
            return File(bytes, contentType, fileDownloadName);
        }
    }
}
