using System;

namespace WebApplication1
{
    public class File
    {
        public int FileId { get; set; }
        public string FileType { get; set; }
        public string FileDate { get; set; }
        public byte[] FilePdf { get; set; }
        public string FileLocation { get; set; }
        public string FilePlant { get; set; }
        public string FileTerm { get; set; }
        public DateTime? FileUploadDate { get; set; }
        public string FileUploadedBy { get; set; }

        public string CompanyName { get; set; }

    }
}
